package com.healthcare.fog.ci;

import java.util.Random;

/**
 * Simplified PSO for optimizing feature weights
 */
public class SimplePSO {
    private static final int NUM_PARTICLES = 30;
    private static final int MAX_ITERATIONS = 30;
    private static final double W = 0.7;
    private static final double C1 = 1.5;
    private static final double C2 = 1.5;
    
    private int dimensions;
    private Random random;
    private double lastBestFitness = Double.NEGATIVE_INFINITY;
    private double fitnessAt10 = 0.0;
    private double fitnessAt20 = 0.0;
    private double fitnessAt30 = 0.0;
    
    private class Particle {
        double[] position;
        double[] velocity;
        double[] pBest;
        double pBestFitness;
        
        Particle(int dimensions) {
            position = new double[dimensions];
            velocity = new double[dimensions];
            pBest = new double[dimensions];
            pBestFitness = Double.NEGATIVE_INFINITY;
        }
    }
    
    public SimplePSO(int dimensions) {
        this.dimensions = dimensions;
        this.random = new Random(42);
    }
    
    /**
     * Optimize weights to maximize classification accuracy
     */
    public double[] optimize(double[][] features, int[] labels) {
        System.out.println("Running PSO optimization...");
        System.out.printf("Particles: %d, Iterations: %d%n", NUM_PARTICLES, MAX_ITERATIONS);
        
        // Initialize swarm
        Particle[] swarm = new Particle[NUM_PARTICLES];
        for (int i = 0; i < NUM_PARTICLES; i++) {
            swarm[i] = new Particle(dimensions);
            for (int d = 0; d < dimensions; d++) {
                swarm[i].position[d] = random.nextDouble();
                swarm[i].velocity[d] = (random.nextDouble() - 0.5) * 0.2;
            }
        }
        
        double[] gBest = new double[dimensions];
        double gBestFitness = Double.NEGATIVE_INFINITY;
        
        // PSO iterations
        for (int iter = 0; iter < MAX_ITERATIONS; iter++) {
            // Evaluate fitness for each particle
            for (Particle particle : swarm) {
                double fitness = evaluateFitness(particle.position, features, labels);
                
                // Update personal best
                if (fitness > particle.pBestFitness) {
                    particle.pBestFitness = fitness;
                    System.arraycopy(particle.position, 0, particle.pBest, 0, dimensions);
                }
                
                // Update global best
                if (fitness > gBestFitness) {
                    gBestFitness = fitness;
                    System.arraycopy(particle.position, 0, gBest, 0, dimensions);
                }
            }
            
            // Update particle positions
            for (Particle particle : swarm) {
                for (int d = 0; d < dimensions; d++) {
                    double r1 = random.nextDouble();
                    double r2 = random.nextDouble();
                    
                    particle.velocity[d] = W * particle.velocity[d] +
                        C1 * r1 * (particle.pBest[d] - particle.position[d]) +
                        C2 * r2 * (gBest[d] - particle.position[d]);
                    
                    // Clamp velocity
                    particle.velocity[d] = Math.max(-0.5, Math.min(0.5, particle.velocity[d]));
                    
                    particle.position[d] += particle.velocity[d];
                    
                    // Clamp position
                    particle.position[d] = Math.max(0.0, Math.min(1.0, particle.position[d]));
                }
            }
            
            // Track fitness at specific iterations
            if (iter + 1 == 10) {
                fitnessAt10 = gBestFitness;
            } else if (iter + 1 == 20) {
                fitnessAt20 = gBestFitness;
            } else if (iter + 1 == 30) {
                fitnessAt30 = gBestFitness;
            }
            
            if ((iter + 1) % 10 == 0) {
                System.out.printf("Iteration %d/%d - Best Fitness: %.4f%n", 
                    iter + 1, MAX_ITERATIONS, gBestFitness);
            }
        }
        lastBestFitness = gBestFitness;
        System.out.printf("PSO completed - Final Fitness: %.4f%n", gBestFitness);
        return gBest;
    }
    
    /**
     * Evaluate fitness based on classification accuracy
     */
    private double evaluateFitness(double[] weights, double[][] features, int[] labels) {
        int correct = 0;
        
        for (int i = 0; i < features.length; i++) {
            // Weighted sum
            double score = 0;
            for (int j = 0; j < Math.min(features[i].length, weights.length); j++) {
                score += features[i][j] * weights[j];
            }
            
            // Classify based on score
            int predicted;
            if (score < 0.1) {
                predicted = 0; // Normal
            } else if (score < 0.15) {
                predicted = 1; // Warning
            } else {
                predicted = 2; // Critical
            }
            
            if (predicted == labels[i]) {
                correct++;
            }
        }
        
        return (double) correct / features.length;
    }

    public double getLastBestFitness() {
        return lastBestFitness;
    }
    
    public double getFitnessAt10() {
        return fitnessAt10;
    }
    
    public double getFitnessAt20() {
        return fitnessAt20;
    }
    
    public double getFitnessAt30() {
        return fitnessAt30;
    }
}
