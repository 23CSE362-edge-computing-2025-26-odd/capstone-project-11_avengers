package com.healthcare.fog.ci;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Generates synthetic healthcare sensor data for training and testing
 * Simulates: Temperature, Blood Pressure, Respiration Rate, Heart Rate
 */
public class DataGenerator {
    private static final Random random = new Random(42);
    
    // Normal ranges for vital signs
    private static final double TEMP_NORMAL_MEAN = 37.0;
    private static final double TEMP_NORMAL_STD = 0.5;
    private static final double BP_SYSTOLIC_NORMAL_MEAN = 120.0;
    private static final double BP_SYSTOLIC_NORMAL_STD = 10.0;
    private static final double BP_DIASTOLIC_NORMAL_MEAN = 80.0;
    private static final double BP_DIASTOLIC_NORMAL_STD = 8.0;
    private static final double RESP_NORMAL_MEAN = 16.0;
    private static final double RESP_NORMAL_STD = 2.0;
    private static final double HR_NORMAL_MEAN = 75.0;
    private static final double HR_NORMAL_STD = 10.0;
    
    public static class VitalSignData {
        public double temperature;
        public double bpSystolic;
        public double bpDiastolic;
        public double respirationRate;
        public double heartRate;
        public int label; // 0=Normal, 1=Warning, 2=Critical
        public String severity;
        
        public VitalSignData(double temp, double bpSys, double bpDia, double resp, double hr, int label) {
            this.temperature = temp;
            this.bpSystolic = bpSys;
            this.bpDiastolic = bpDia;
            this.respirationRate = resp;
            this.heartRate = hr;
            this.label = label;
            this.severity = label == 0 ? "Normal" : (label == 1 ? "Warning" : "Critical");
        }
        
        public double[] toArray() {
            return new double[]{temperature, bpSystolic, bpDiastolic, respirationRate, heartRate};
        }
    }
    
    /**
     * Generate normal vital signs
     */
    private static VitalSignData generateNormal() {
        double temp = TEMP_NORMAL_MEAN + random.nextGaussian() * TEMP_NORMAL_STD;
        double bpSys = BP_SYSTOLIC_NORMAL_MEAN + random.nextGaussian() * BP_SYSTOLIC_NORMAL_STD;
        double bpDia = BP_DIASTOLIC_NORMAL_MEAN + random.nextGaussian() * BP_DIASTOLIC_NORMAL_STD;
        double resp = RESP_NORMAL_MEAN + random.nextGaussian() * RESP_NORMAL_STD;
        double hr = HR_NORMAL_MEAN + random.nextGaussian() * HR_NORMAL_STD;
        
        return new VitalSignData(temp, bpSys, bpDia, resp, hr, 0);
    }
    
    /**
     * Generate warning level vital signs (mild abnormalities)
     */
    private static VitalSignData generateWarning() {
        double temp = random.nextBoolean() ? 
            TEMP_NORMAL_MEAN + 1.0 + random.nextDouble() * 0.8 : // Fever
            TEMP_NORMAL_MEAN - 1.0 - random.nextDouble() * 0.5;  // Hypothermia
        
        double bpSys = random.nextBoolean() ?
            BP_SYSTOLIC_NORMAL_MEAN + 20 + random.nextDouble() * 20 : // High
            BP_SYSTOLIC_NORMAL_MEAN - 15 - random.nextDouble() * 10;  // Low
        
        double bpDia = random.nextBoolean() ?
            BP_DIASTOLIC_NORMAL_MEAN + 10 + random.nextDouble() * 10 :
            BP_DIASTOLIC_NORMAL_MEAN - 10 - random.nextDouble() * 5;
        
        double resp = random.nextBoolean() ?
            RESP_NORMAL_MEAN + 6 + random.nextDouble() * 4 : // Tachypnea
            RESP_NORMAL_MEAN - 4 - random.nextDouble() * 2;  // Bradypnea
        
        double hr = random.nextBoolean() ?
            HR_NORMAL_MEAN + 25 + random.nextDouble() * 20 : // Tachycardia
            HR_NORMAL_MEAN - 20 - random.nextDouble() * 10;  // Bradycardia
        
        return new VitalSignData(temp, bpSys, bpDia, resp, hr, 1);
    }
    
    /**
     * Generate critical level vital signs (severe abnormalities)
     */
    private static VitalSignData generateCritical() {
        double temp = random.nextBoolean() ?
            TEMP_NORMAL_MEAN + 2.5 + random.nextDouble() * 1.5 : // High fever
            TEMP_NORMAL_MEAN - 2.0 - random.nextDouble() * 1.0;  // Severe hypothermia
        
        double bpSys = random.nextBoolean() ?
            BP_SYSTOLIC_NORMAL_MEAN + 50 + random.nextDouble() * 30 : // Hypertensive crisis
            BP_SYSTOLIC_NORMAL_MEAN - 30 - random.nextDouble() * 20;  // Hypotensive shock
        
        double bpDia = random.nextBoolean() ?
            BP_DIASTOLIC_NORMAL_MEAN + 25 + random.nextDouble() * 15 :
            BP_DIASTOLIC_NORMAL_MEAN - 20 - random.nextDouble() * 10;
        
        double resp = random.nextBoolean() ?
            RESP_NORMAL_MEAN + 12 + random.nextDouble() * 8 : // Severe tachypnea
            RESP_NORMAL_MEAN - 8 - random.nextDouble() * 4;   // Severe bradypnea
        
        double hr = random.nextBoolean() ?
            HR_NORMAL_MEAN + 50 + random.nextDouble() * 40 : // Severe tachycardia
            HR_NORMAL_MEAN - 35 - random.nextDouble() * 15;  // Severe bradycardia
        
        return new VitalSignData(temp, bpSys, bpDia, resp, hr, 2);
    }
    
    /**
     * Generate balanced dataset
     */
    public static List<VitalSignData> generateDataset(int normalCount, int warningCount, int criticalCount) {
        List<VitalSignData> dataset = new ArrayList<>();
        
        for (int i = 0; i < normalCount; i++) {
            dataset.add(generateNormal());
        }
        
        for (int i = 0; i < warningCount; i++) {
            dataset.add(generateWarning());
        }
        
        for (int i = 0; i < criticalCount; i++) {
            dataset.add(generateCritical());
        }
        
        return dataset;
    }

    /**
     * Generate a single sample for a requested severity level.
     * @param severityLabel 0=Normal, 1=Warning, 2=Critical
     */
    public static VitalSignData generateSampleForSeverity(int severityLabel) {
        if (severityLabel <= 0) {
            return generateNormal();
        } else if (severityLabel == 1) {
            return generateWarning();
        } else {
            return generateCritical();
        }
    }

    /**
     * Save dataset to CSV file
     */
    public static void saveToCSV(List<VitalSignData> dataset, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            writer.write("Temperature,BPSystolic,BPDiastolic,RespirationRate,HeartRate,Label,Severity\n");
            
            for (VitalSignData data : dataset) {
                writer.write(String.format("%.2f,%.2f,%.2f,%.2f,%.2f,%d,%s\n",
                    data.temperature, data.bpSystolic, data.bpDiastolic,
                    data.respirationRate, data.heartRate, data.label, data.severity));
            }
            
            System.out.println("Dataset saved to " + filename);
        } catch (IOException e) {
            System.err.println("Error saving dataset: " + e.getMessage());
        }
    }
    
    /**
     * Normalize data to [0, 1] range for CNN input
     * Uses wider ranges to capture all possible values from normal to critical
     */
    public static double[] normalize(double[] data) {
        // Min-max normalization based on full physiological ranges
        double[] mins = {33.0, 60.0, 40.0, 4.0, 30.0};   // Min values (extreme low)
        double[] maxs = {42.0, 220.0, 140.0, 35.0, 200.0}; // Max values (extreme high)
        
        double[] normalized = new double[data.length];
        for (int i = 0; i < data.length; i++) {
            normalized[i] = (data[i] - mins[i]) / (maxs[i] - mins[i]);
            normalized[i] = Math.max(0.0, Math.min(1.0, normalized[i])); // Clamp to [0,1]
        }
        
        return normalized;
    }
}
