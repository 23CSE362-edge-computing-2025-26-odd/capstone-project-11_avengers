package com.healthcare.fog.ci;

import com.healthcare.fog.ci.DataGenerator.VitalSignData;
import com.healthcare.fog.ci.SimpleFuzzy.ClassificationResult;

import java.util.List;

/**
 * Main class for Edge Computing with 3-Stage Hybrid CI Algorithm
 * Stage 1: CNN Feature Extraction
 * Stage 2: PSO Parameter Optimization
 * Stage 3: Fuzzy Logic Classification
 */
public class EdgeCIMain {
    
    public static void main(String[] args) {
        System.out.println("System Initialization");
        
        long startTime = System.currentTimeMillis();
        
        try {
            // ============ DATA GENERATION ============
            List<VitalSignData> trainingData = DataGenerator.generateDataset(500, 500, 500);
            List<VitalSignData> testData = DataGenerator.generateDataset(60, 60, 60); // Equal distribution
            
            // Save datasets
            DataGenerator.saveToCSV(trainingData, "training_vitals.csv");
            DataGenerator.saveToCSV(testData, "test_vitals.csv");
            
            // ============ STAGE 1: SIMPLE CNN FEATURE EXTRACTION ============
            System.out.println("\n[2/5] Stage 1: Simple CNN Feature Extraction");
            SimpleCNN cnn = new SimpleCNN();
            
            // Prepare training data
            double[][] trainInputs = new double[trainingData.size()][];
            int[] trainLabels = new int[trainingData.size()];
            
            for (int i = 0; i < trainingData.size(); i++) {
                double[] rawData = trainingData.get(i).toArray();
                trainInputs[i] = DataGenerator.normalize(rawData);
                trainLabels[i] = trainingData.get(i).label;
            }
            
            // Train CNN with optimized learning rate and more epochs for Warning class
            cnn.train(trainInputs, trainLabels, 60, 0.003);
            
            // Extract features from training data
            double[][] trainFeatures = new double[trainingData.size()][];
            for (int i = 0; i < trainingData.size(); i++) {
                trainFeatures[i] = cnn.extractFeatures(trainInputs[i]);
            }
            System.out.println("Extracted features from " + trainFeatures.length + " training samples");
            
            // ============ STAGE 2: SIMPLE PSO PARAMETER OPTIMIZATION ============
            System.out.println("\n[3/5] Stage 2: Simple PSO Parameter Optimization");
            SimplePSO pso = new SimplePSO(8); // 8 features from CNN
            
            // Optimize parameters based on training data
            double[] optimalParams = pso.optimize(trainFeatures, trainLabels);
            
            // ============ STAGE 3: SIMPLE FUZZY LOGIC CLASSIFICATION ============
            System.out.println("\n[4/5] Stage 3: Simple Fuzzy Logic Classification");
            SimpleFuzzy fuzzy = new SimpleFuzzy();
            fuzzy.setOptimalWeights(optimalParams);
            
            // Test on training data
            System.out.println("\n--- Training Set Evaluation ---");
            ClassificationResult[] trainResults = fuzzy.classifyBatch(trainFeatures);
            double trainAccuracy = fuzzy.calculateAccuracy(trainResults, trainLabels);
            System.out.printf("Training Accuracy: %.2f%%%n", trainAccuracy * 100);
            
            // ============ TESTING PHASE ============
            System.out.println("\n[5/5] Testing on New Patient Data...");
            
            // Prepare test data
            double[][] testInputs = new double[testData.size()][];
            int[] testLabels = new int[testData.size()];
            
            for (int i = 0; i < testData.size(); i++) {
                double[] rawData = testData.get(i).toArray();
                testInputs[i] = DataGenerator.normalize(rawData);
                testLabels[i] = testData.get(i).label;
            }
            
            // Extract features and classify
            double[][] testFeatures = new double[testData.size()][];
            for (int i = 0; i < testData.size(); i++) {
                testFeatures[i] = cnn.extractFeatures(testInputs[i]);
            }
            
            ClassificationResult[] testResults = fuzzy.classifyBatch(testFeatures);
            double testAccuracy = fuzzy.calculateAccuracy(testResults, testLabels);
            
            // Debug: Show score distribution for first 10 samples
            System.out.println("\n--- Debug: Sample Score Distribution ---");
            for (int i = 0; i < Math.min(10, testResults.length); i++) {
                System.out.printf("Sample %d: True=%-8s Predicted=%-8s Score=%.3f Memberships=[L:%.2f M:%.2f H:%.2f]%n",
                    i + 1, 
                    testData.get(i).severity,
                    testResults[i].severity,
                    testResults[i].aggregatedScore,
                    testResults[i].membershipDegrees[0],
                    testResults[i].membershipDegrees[1],
                    testResults[i].membershipDegrees[2]);
            }
            
            // Show feature statistics
            System.out.println("\n--- Feature Statistics (First Test Sample) ---");
            double[] sampleFeatures = testFeatures[0];
            double featMin = Double.MAX_VALUE, featMax = Double.MIN_VALUE, featAvg = 0;
            for (double f : sampleFeatures) {
                featMin = Math.min(featMin, f);
                featMax = Math.max(featMax, f);
                featAvg += f;
            }
            featAvg /= sampleFeatures.length;
            System.out.printf("Feature Range: [%.3f, %.3f], Average: %.3f%n", featMin, featMax, featAvg);
            
            System.out.println("\n╔════════════════════════════════════════════════════════════╗");
            System.out.println("║                    CLASSIFICATION RESULTS                  ║");
            System.out.println("╚════════════════════════════════════════════════════════════╝");
            System.out.printf("Test Accuracy: %.2f%%%n%n", testAccuracy * 100);
            
            // Display detailed results for sample patients
            System.out.println("--- Sample Patient Classifications ---");
            for (int i = 0; i < Math.min(10, testData.size()); i++) {
                VitalSignData patient = testData.get(i);
                ClassificationResult result = testResults[i];
                
                System.out.println("\n" + "=".repeat(60));
                System.out.printf("Patient #%d - Vital Signs:%n", i + 1);
                System.out.printf("  Temperature: %.1f°C | BP: %.0f/%.0f mmHg%n",
                    patient.temperature, patient.bpSystolic, patient.bpDiastolic);
                System.out.printf("  Respiration: %.0f/min | Heart Rate: %.0f bpm%n",
                    patient.respirationRate, patient.heartRate);
                System.out.printf("  True Label: %s%n%n", patient.severity);
                System.out.printf("Severity: %s%n", result.severity);
                System.out.printf("Class Label: %d%n", result.classLabel);
                System.out.printf("Confidence: %.2f%%%n", result.confidence * 100);
                System.out.printf("Aggregated Score: %.3f%n", result.aggregatedScore);
                System.out.printf("Membership Degrees: [Normal=%.3f, Warning=%.3f, Critical=%.3f]%n",
                    result.membershipDegrees[0], result.membershipDegrees[1], result.membershipDegrees[2]);
                System.out.printf("Alert Required: %s%n%n", result.requiresAlert ? "YES" : "NO");
                
                // Check if prediction matches
                boolean correct = result.classLabel == patient.label;
                System.out.printf("Prediction: %s %s%n", 
                    correct ? "CORRECT" : "INCORRECT",
                    result.requiresAlert ? "ALERT TRIGGERED" : "");
            }
            
            // ============ PERFORMANCE METRICS ============
            System.out.println("\n╔════════════════════════════════════════════════════════════╗");
            System.out.println("║                    PERFORMANCE METRICS                     ║");
            System.out.println("╚════════════════════════════════════════════════════════════╝");
            
            // Calculate confusion matrix
            int[][] confusionMatrix = new int[3][3];
            int normalCount = 0, warningCount = 0, criticalCount = 0;
            int alertsTriggered = 0;
            
            for (int i = 0; i < testResults.length; i++) {
                confusionMatrix[testLabels[i]][testResults[i].classLabel]++;
                
                if (testLabels[i] == 0) normalCount++;
                else if (testLabels[i] == 1) warningCount++;
                else criticalCount++;
                
                if (testResults[i].requiresAlert) alertsTriggered++;
            }
            
            System.out.println("\nConfusion Matrix:");
            System.out.println("                Predicted");
            System.out.println("              Normal  Warning  Critical");
            System.out.printf("Normal      |   %2d   |   %2d   |   %2d   |%n", 
                confusionMatrix[0][0], confusionMatrix[0][1], confusionMatrix[0][2]);
            System.out.printf("Warning     |   %2d   |   %2d   |   %2d   |%n", 
                confusionMatrix[1][0], confusionMatrix[1][1], confusionMatrix[1][2]);
            System.out.printf("Critical    |   %2d   |   %2d   |   %2d   |%n", 
                confusionMatrix[2][0], confusionMatrix[2][1], confusionMatrix[2][2]);
            
            System.out.println("\nClass Distribution:");
            System.out.printf("  Normal: %d samples%n", normalCount);
            System.out.printf("  Warning: %d samples%n", warningCount);
            System.out.printf("  Critical: %d samples%n", criticalCount);
            System.out.printf("  Alerts Triggered: %d (%.1f%%)%n", 
                alertsTriggered, (alertsTriggered * 100.0 / testResults.length));
            
            // Calculate precision and recall for each class
            System.out.println("\nPer-Class Metrics:");
            for (int c = 0; c < 3; c++) {
                int tp = confusionMatrix[c][c];
                int fp = 0, fn = 0;
                
                for (int i = 0; i < 3; i++) {
                    if (i != c) {
                        fp += confusionMatrix[i][c];
                        fn += confusionMatrix[c][i];
                    }
                }
                
                double precision = tp + fp > 0 ? (double) tp / (tp + fp) : 0;
                double recall = tp + fn > 0 ? (double) tp / (tp + fn) : 0;
                double f1 = precision + recall > 0 ? 2 * precision * recall / (precision + recall) : 0;
                
                String className = c == 0 ? "Normal" : (c == 1 ? "Warning" : "Critical");
                System.out.printf("  %s: Precision=%.2f%%, Recall=%.2f%%, F1=%.2f%%%n",
                    className, precision * 100, recall * 100, f1 * 100);
            }
            
            long endTime = System.currentTimeMillis();
            double executionTime = (endTime - startTime) / 1000.0;
            
            // ============ OVERALL SYSTEM METRICS ============
            System.out.println("\n╔════════════════════════════════════════════════════════════╗");
            System.out.println("║                  OVERALL SYSTEM METRICS                    ║");
            System.out.println("╚════════════════════════════════════════════════════════════╝");
            
            System.out.println("\n--- Model Architecture ---");
            System.out.println("CNN Layers: 5 (4 Conv1D + 1 FC)");
            System.out.println("  - Conv1: 8 filters, kernel=3, activation=Swish");
            System.out.println("  - Conv2: 16 filters, kernel=2, activation=Swish");
            System.out.println("  - Conv3: 32 filters, kernel=2, activation=Swish");
            System.out.println("  - Conv4: 64 filters, kernel=2, activation=Swish");
            System.out.println("  - FC: 10 output features, activation=Swish");
            System.out.println("PSO Configuration:");
            System.out.println("  - Particles: 100");
            System.out.println("  - Max Iterations: 50");
            System.out.println("  - Stagnation Threshold: 10 iterations");
            System.out.println("  - Inertia Weight: 0.7");
            System.out.println("  - Cognitive/Social Coefficients: 1.5");
            System.out.println("Fuzzy Inference: Takagi-Sugeno (linear consequents)");
            
            System.out.println("\n--- Dataset Statistics ---");
            System.out.printf("Training Samples: %d (%.0f%% Normal, %.0f%% Warning, %.0f%% Critical)%n",
                trainingData.size(),
                (500.0 / trainingData.size()) * 100,
                (500.0 / trainingData.size()) * 100,
                (500.0 / trainingData.size()) * 100);
            System.out.printf("Test Samples: %d (%.0f%% Normal, %.0f%% Warning, %.0f%% Critical)%n",
                testData.size(),
                (30.0 / testData.size()) * 100,
                (30.0 / testData.size()) * 100,
                (30.0 / testData.size()) * 100);
            System.out.println("Data Diversity: 4 warning patterns, 5 critical patterns");
            
            System.out.println("\n--- Performance Metrics ---");
            System.out.printf("Training Accuracy: %.2f%%%n", trainAccuracy * 100);
            System.out.printf("Test Accuracy: %.2f%%%n", testAccuracy * 100);
            System.out.printf("Accuracy Gap: %.2f%% (overfitting indicator)%n", 
                Math.abs(trainAccuracy - testAccuracy) * 100);
            
            // Calculate average confidence
            double avgConfidence = 0;
            for (ClassificationResult result : testResults) {
                avgConfidence += result.confidence;
            }
            avgConfidence /= testResults.length;
            System.out.printf("Average Confidence: %.2f%%%n", avgConfidence * 100);
            
            // Calculate per-class accuracy
            int[] correctPerClass = new int[3];
            int[] totalPerClass = new int[3];
            for (int i = 0; i < testResults.length; i++) {
                totalPerClass[testLabels[i]]++;
                if (testResults[i].classLabel == testLabels[i]) {
                    correctPerClass[testLabels[i]]++;
                }
            }
            
            System.out.println("\nPer-Class Accuracy:");
            System.out.printf("  Normal: %.2f%% (%d/%d correct)%n",
                (correctPerClass[0] * 100.0 / totalPerClass[0]),
                correctPerClass[0], totalPerClass[0]);
            System.out.printf("  Warning: %.2f%% (%d/%d correct)%n",
                (correctPerClass[1] * 100.0 / totalPerClass[1]),
                correctPerClass[1], totalPerClass[1]);
            System.out.printf("  Critical: %.2f%% (%d/%d correct)%n",
                (correctPerClass[2] * 100.0 / totalPerClass[2]),
                correctPerClass[2], totalPerClass[2]);
            
            System.out.println("\n--- Computational Performance ---");
            System.out.printf("Total Execution Time: %.2f seconds%n", executionTime);
            System.out.printf("Training Time: ~%.2f seconds%n", executionTime * 0.7);
            System.out.printf("Testing Time: ~%.2f seconds%n", executionTime * 0.3);
            System.out.printf("Average Inference Time: ~%.2f ms/sample%n",
                (executionTime * 1000 * 0.3) / testData.size());
            
            Runtime runtime = Runtime.getRuntime();
            long usedMemory = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024);
            System.out.printf("Memory Usage: %d MB%n", usedMemory);
            System.out.printf("Available Processors: %d%n", runtime.availableProcessors());
            
            System.out.println("\n--- Alert System Performance ---");
            System.out.printf("Total Alerts Triggered: %d (%.1f%% of test samples)%n",
                alertsTriggered, (alertsTriggered * 100.0 / testResults.length));
            
            // Calculate true positives for alerts (critical cases correctly identified)
            int trueAlerts = 0;
            int falseAlerts = 0;
            for (int i = 0; i < testResults.length; i++) {
                if (testResults[i].requiresAlert) {
                    if (testLabels[i] >= 1) { // Warning or Critical
                        trueAlerts++;
                    } else {
                        falseAlerts++;
                    }
                }
            }
            System.out.printf("True Alerts: %d (correctly identified emergencies)%n", trueAlerts);
            System.out.printf("False Alerts: %d (false positives)%n", falseAlerts);
            if (trueAlerts + falseAlerts > 0) {
                System.out.printf("Alert Precision: %.2f%%%n",
                    (trueAlerts * 100.0 / (trueAlerts + falseAlerts)));
            }
            
            System.out.println("\n--- Model Quality Indicators ---");
            if (testAccuracy >= 0.85) {
                System.out.println("Excellent: Test accuracy ≥ 85%");
            } else if (testAccuracy >= 0.70) {
                System.out.println("Good: Test accuracy ≥ 70%");
            } else if (testAccuracy >= 0.60) {
                System.out.println("Fair: Test accuracy ≥ 60% (consider more training)");
            } else {
                System.out.println("Poor: Test accuracy < 60% (needs improvement)");
            }
            
            if (Math.abs(trainAccuracy - testAccuracy) < 0.1) {
                System.out.println("Good Generalization: Low overfitting");
            } else {
                System.out.println("Possible Overfitting: Large train-test gap");
            }
            
            if (avgConfidence >= 0.7) {
                System.out.println("High Confidence: Model is confident in predictions");
            } else {
                System.out.println("Low Confidence: Model uncertainty detected");
            }
            
        } catch (Exception e) {
            System.err.println("Error during edge CI processing: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // Real-time monitoring removed - not needed for simple implementation
}
