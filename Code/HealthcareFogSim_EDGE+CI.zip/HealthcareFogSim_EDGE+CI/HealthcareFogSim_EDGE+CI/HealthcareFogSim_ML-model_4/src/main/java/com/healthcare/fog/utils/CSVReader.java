package com.healthcare.fog.utils;

import com.healthcare.fog.entities.HealthcareTask;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CSVReader {
    public static List<HealthcareTask> readTasksFromCSV(String filename) {
        List<HealthcareTask> tasks = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            boolean firstLine = true;

            while ((line = br.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }

                String[] parts = line.split(",");
                if (parts.length < 9) continue;

                int taskId = Integer.parseInt(parts[0].trim());
                String taskType = parts[1].trim();
                int dataSizeBytes = Integer.parseInt(parts[2].trim());
                int cpuReqMI = Integer.parseInt(parts[3].trim());
                int deadlineMs = Integer.parseInt(parts[4].trim());
                int urgency = Integer.parseInt(parts[5].trim());
                double energyEst = Double.parseDouble(parts[6].trim());
                int sourceId = Integer.parseInt(parts[7].trim());
                int arrivalMs = Integer.parseInt(parts[8].trim());

                HealthcareTask task = new HealthcareTask(taskId, taskType, dataSizeBytes, cpuReqMI,
                        deadlineMs, urgency, energyEst, sourceId, arrivalMs);
                tasks.add(task);
            }
        } catch (IOException e) {
            System.err.println("Error reading CSV: " + e.getMessage());
        }

        return tasks;
    }
}