package com.healthcare.fog.ci;

import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Enhanced CNN for Healthcare Vital Sign Feature Extraction
 * Features: Proper output layer, Adam optimizer, class weighting, full backpropagation
 */
public class SimpleCNN {
    // Network architecture
    private double[][] weightsInputHidden;  // Input -> Hidden weights
    private double[] biasHidden;            // Hidden layer bias
    private double[][] weightsHiddenOutput; // Hidden -> Output weights
    private double[] biasOutput;            // Output layer bias
    
    // Adam optimizer parameters
    private double[][] mInputHidden, vInputHidden;  // Momentum for input->hidden
    private double[] mBiasHidden, vBiasHidden;      // Momentum for hidden bias
    private double[][] mHiddenOutput, vHiddenOutput; // Momentum for hidden->output
    private double[] mBiasOutput, vBiasOutput;      // Momentum for output bias
    
    private static final double BETA1 = 0.9;        // Adam beta1
    private static final double BETA2 = 0.999;      // Adam beta2
    private static final double EPSILON = 1e-8;     // Adam epsilon
    private static final double DROPOUT_RATE = 0.18; // Slightly reduced dropout
    
    private Random random;
    
    private static final int INPUT_SIZE = 5;   // 5 vital signs
    private static final int HIDDEN_SIZE = 8;  // Keep at 8 for pipeline compatibility
    private static final int OUTPUT_SIZE = 3;  // 3 classes: Normal, Warning, Critical
    
    // Class weights for handling imbalanced learning (2.2x for Warning class)
    private static final double[] CLASS_WEIGHTS = {1.0, 2.2, 1.0};
    
    public SimpleCNN() {
        this.random = new Random(42);
        initializeWeights();
        initializeAdamParameters();
    }
    
    private void initializeWeights() {
        // Xavier/He initialization for better gradient flow
        weightsInputHidden = new double[INPUT_SIZE][HIDDEN_SIZE];
        biasHidden = new double[HIDDEN_SIZE];
        weightsHiddenOutput = new double[HIDDEN_SIZE][OUTPUT_SIZE];
        biasOutput = new double[OUTPUT_SIZE];
        
        // Input -> Hidden (He initialization for ReLU)
        double scaleInputHidden = Math.sqrt(2.0 / INPUT_SIZE);
        for (int i = 0; i < INPUT_SIZE; i++) {
            for (int j = 0; j < HIDDEN_SIZE; j++) {
                weightsInputHidden[i][j] = random.nextGaussian() * scaleInputHidden;
            }
        }
        
        // Hidden -> Output (Xavier initialization for softmax)
        double scaleHiddenOutput = Math.sqrt(2.0 / (HIDDEN_SIZE + OUTPUT_SIZE));
        for (int i = 0; i < HIDDEN_SIZE; i++) {
            for (int j = 0; j < OUTPUT_SIZE; j++) {
                weightsHiddenOutput[i][j] = random.nextGaussian() * scaleHiddenOutput;
            }
        }
        
        // Initialize biases
        for (int i = 0; i < HIDDEN_SIZE; i++) {
            biasHidden[i] = 0.01;
        }
        for (int i = 0; i < OUTPUT_SIZE; i++) {
            biasOutput[i] = 0.0;
        }
    }
    
    private void initializeAdamParameters() {
        // Initialize Adam momentum and velocity matrices
        mInputHidden = new double[INPUT_SIZE][HIDDEN_SIZE];
        vInputHidden = new double[INPUT_SIZE][HIDDEN_SIZE];
        mBiasHidden = new double[HIDDEN_SIZE];
        vBiasHidden = new double[HIDDEN_SIZE];
        mHiddenOutput = new double[HIDDEN_SIZE][OUTPUT_SIZE];
        vHiddenOutput = new double[HIDDEN_SIZE][OUTPUT_SIZE];
        mBiasOutput = new double[OUTPUT_SIZE];
        vBiasOutput = new double[OUTPUT_SIZE];
    }
    
    /**
     * ReLU activation
     */
    private double relu(double x) {
        return Math.max(0, x);
    }
    
    /**
     * ReLU derivative
     */
    private double reluDerivative(double x) {
        return x > 0 ? 1.0 : 0.0;
    }
    
    /**
     * Softmax activation for output layer
     */
    private double[] softmax(double[] x) {
        double[] result = new double[x.length];
        double max = x[0];
        for (double val : x) {
            if (val > max) max = val;
        }
        
        double sum = 0;
        for (int i = 0; i < x.length; i++) {
            result[i] = Math.exp(x[i] - max);
            sum += result[i];
        }
        
        for (int i = 0; i < result.length; i++) {
            result[i] /= sum;
        }
        
        return result;
    }
    
    /**
     * Forward pass through the network
     */
    private ForwardResult forward(double[] input, boolean training) {
        ForwardResult result = new ForwardResult();
        result.input = input;
        result.hidden = new double[HIDDEN_SIZE];
        result.hiddenPreActivation = new double[HIDDEN_SIZE];
        result.output = new double[OUTPUT_SIZE];
        result.outputPreActivation = new double[OUTPUT_SIZE];
        
        // Input -> Hidden
        for (int j = 0; j < HIDDEN_SIZE; j++) {
            double sum = biasHidden[j];
            for (int i = 0; i < INPUT_SIZE; i++) {
                sum += input[i] * weightsInputHidden[i][j];
            }
            result.hiddenPreActivation[j] = sum;
            result.hidden[j] = relu(sum);
            
            // Apply dropout during training
            if (training && random.nextDouble() < DROPOUT_RATE) {
                result.hidden[j] = 0;
            } else if (training) {
                result.hidden[j] /= (1.0 - DROPOUT_RATE);
            }
        }
        
        // Hidden -> Output
        for (int j = 0; j < OUTPUT_SIZE; j++) {
            double sum = biasOutput[j];
            for (int i = 0; i < HIDDEN_SIZE; i++) {
                sum += result.hidden[i] * weightsHiddenOutput[i][j];
            }
            result.outputPreActivation[j] = sum;
        }
        
        // Softmax activation
        result.output = softmax(result.outputPreActivation);
        
        return result;
    }
    
    /**
     * Extract features from normalized vital signs (for compatibility)
     */
    public double[] extractFeatures(double[] input) {
        ForwardResult result = forward(input, false);
        return result.hidden;
    }
    
    /**
     * Enhanced training with Adam optimizer and full backpropagation
     */
    public TrainingMetrics train(double[][] trainingData, int[] labels, int epochs, double learningRate) {
        return train(trainingData, labels, epochs, learningRate, false);
    }
    
    /**
     * Enhanced training with Adam optimizer and full backpropagation
     * @param verbose if true, prints detailed training progress
     */
    public TrainingMetrics train(double[][] trainingData, int[] labels, int epochs, double learningRate, boolean verbose) {
        if (verbose) {
            System.out.println("Training Enhanced CNN with Adam Optimizer (Warning-Focused)...");
            System.out.println("Architecture: Input(5) -> Hidden(8, ReLU) -> Output(3, Softmax)");
            System.out.println("Optimizer: Adam (β1=0.9, β2=0.999, ε=1e-8)");
            System.out.println("Class Weights: [Normal=1.0, Warning=2.2, Critical=1.0]");
            System.out.println("Dropout: 0.18 (slightly reduced)");
            System.out.println("Learning Rate: " + learningRate);
        }
        
        // Create shuffled indices for each epoch
        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < trainingData.length; i++) {
            indices.add(i);
        }
        
        int t = 0; // Adam timestep
        
        double finalAccuracy = 0.0;
        double finalLoss = 0.0;
        int finalEpoch = 0;
        double finalNormalRecall = 0.0;
        double finalWarningRecall = 0.0;
        double finalCriticalRecall = 0.0;

        for (int epoch = 0; epoch < epochs; epoch++) {
            // Shuffle data each epoch
            Collections.shuffle(indices, random);
            
            double totalLoss = 0;
            int correct = 0;
            int[] classCorrect = new int[OUTPUT_SIZE];
            int[] classTotal = new int[OUTPUT_SIZE];
            
            for (int idx : indices) {
                t++;
                
                // Forward pass
                ForwardResult fwd = forward(trainingData[idx], true);
                
                // Create one-hot target
                double[] target = new double[OUTPUT_SIZE];
                target[labels[idx]] = 1.0;
                
                // Calculate cross-entropy loss with class weighting
                double loss = 0;
                for (int i = 0; i < OUTPUT_SIZE; i++) {
                    loss -= target[i] * Math.log(fwd.output[i] + 1e-10) * CLASS_WEIGHTS[labels[idx]];
                }
                totalLoss += loss;
                
                // Prediction
                int predicted = 0;
                double maxProb = fwd.output[0];
                for (int i = 1; i < OUTPUT_SIZE; i++) {
                    if (fwd.output[i] > maxProb) {
                        maxProb = fwd.output[i];
                        predicted = i;
                    }
                }
                
                if (predicted == labels[idx]) {
                    correct++;
                    classCorrect[labels[idx]]++;
                }
                classTotal[labels[idx]]++;
                
                // Backpropagation
                // Output layer gradients (softmax + cross-entropy derivative)
                double[] outputGrad = new double[OUTPUT_SIZE];
                for (int i = 0; i < OUTPUT_SIZE; i++) {
                    outputGrad[i] = (fwd.output[i] - target[i]) * CLASS_WEIGHTS[labels[idx]];
                }
                
                // Hidden layer gradients
                double[] hiddenGrad = new double[HIDDEN_SIZE];
                for (int i = 0; i < HIDDEN_SIZE; i++) {
                    double grad = 0;
                    for (int j = 0; j < OUTPUT_SIZE; j++) {
                        grad += outputGrad[j] * weightsHiddenOutput[i][j];
                    }
                    hiddenGrad[i] = grad * reluDerivative(fwd.hiddenPreActivation[i]);
                }
                
                // Update weights using Adam optimizer
                updateWeightsAdam(fwd, outputGrad, hiddenGrad, learningRate, t);
            }
            
            double accuracy = (double) correct / trainingData.length * 100;
            finalAccuracy = accuracy / 100.0;
            double avgLoss = totalLoss / trainingData.length;
            finalLoss = avgLoss;
            finalEpoch = epoch + 1;
            
            // Calculate per-class recall
            double normalRecall = classTotal[0] > 0 ? (double) classCorrect[0] / classTotal[0] * 100 : 0;
            double warningRecall = classTotal[1] > 0 ? (double) classCorrect[1] / classTotal[1] * 100 : 0;
            double criticalRecall = classTotal[2] > 0 ? (double) classCorrect[2] / classTotal[2] * 100 : 0;
            
            finalNormalRecall = normalRecall;
            finalWarningRecall = warningRecall;
            finalCriticalRecall = criticalRecall;
            
            if (verbose && (epoch + 1) % 5 == 0) {
                System.out.printf("Epoch %d/%d - Loss: %.4f, Accuracy: %.2f%% ",
                    epoch + 1, epochs, avgLoss, accuracy);
                
                // Per-class recall
                System.out.print("[Recall: ");
                for (int i = 0; i < OUTPUT_SIZE; i++) {
                    double recall = classTotal[i] > 0 ? (double) classCorrect[i] / classTotal[i] * 100 : 0;
                    String className = i == 0 ? "N" : (i == 1 ? "W" : "C");
                    System.out.printf("%s=%.0f%% ", className, recall);
                }
                System.out.println("]");
            }
            
            // Early stopping with Warning class check
            if (accuracy > 85.0) {
                if (warningRecall >= 70.0) {
                    if (verbose) {
                        System.out.printf("Early stopping at epoch %d (accuracy: %.2f%%, Warning recall: %.0f%%)%n", 
                            epoch + 1, accuracy, warningRecall);
                    }
                    break;
                }
            }
        }
        
        if (verbose) {
            System.out.println("Enhanced CNN training completed");
        }
        return new TrainingMetrics(finalAccuracy, finalLoss, finalEpoch, 
                                  finalNormalRecall, finalWarningRecall, finalCriticalRecall);
    }
    
    /**
     * Adam optimizer weight update
     */
    private void updateWeightsAdam(ForwardResult fwd, double[] outputGrad, double[] hiddenGrad,
                                   double learningRate, int t) {
        // Update Hidden -> Output weights
        for (int i = 0; i < HIDDEN_SIZE; i++) {
            for (int j = 0; j < OUTPUT_SIZE; j++) {
                double grad = outputGrad[j] * fwd.hidden[i];
                
                // Adam update
                mHiddenOutput[i][j] = BETA1 * mHiddenOutput[i][j] + (1 - BETA1) * grad;
                vHiddenOutput[i][j] = BETA2 * vHiddenOutput[i][j] + (1 - BETA2) * grad * grad;
                
                double mHat = mHiddenOutput[i][j] / (1 - Math.pow(BETA1, t));
                double vHat = vHiddenOutput[i][j] / (1 - Math.pow(BETA2, t));
                
                weightsHiddenOutput[i][j] -= learningRate * mHat / (Math.sqrt(vHat) + EPSILON);
            }
        }
        
        // Update output bias
        for (int j = 0; j < OUTPUT_SIZE; j++) {
            double grad = outputGrad[j];
            
            mBiasOutput[j] = BETA1 * mBiasOutput[j] + (1 - BETA1) * grad;
            vBiasOutput[j] = BETA2 * vBiasOutput[j] + (1 - BETA2) * grad * grad;
            
            double mHat = mBiasOutput[j] / (1 - Math.pow(BETA1, t));
            double vHat = vBiasOutput[j] / (1 - Math.pow(BETA2, t));
            
            biasOutput[j] -= learningRate * mHat / (Math.sqrt(vHat) + EPSILON);
        }
        
        // Update Input -> Hidden weights
        for (int i = 0; i < INPUT_SIZE; i++) {
            for (int j = 0; j < HIDDEN_SIZE; j++) {
                double grad = hiddenGrad[j] * fwd.input[i];
                
                mInputHidden[i][j] = BETA1 * mInputHidden[i][j] + (1 - BETA1) * grad;
                vInputHidden[i][j] = BETA2 * vInputHidden[i][j] + (1 - BETA2) * grad * grad;
                
                double mHat = mInputHidden[i][j] / (1 - Math.pow(BETA1, t));
                double vHat = vInputHidden[i][j] / (1 - Math.pow(BETA2, t));
                
                weightsInputHidden[i][j] -= learningRate * mHat / (Math.sqrt(vHat) + EPSILON);
            }
        }
        
        // Update hidden bias
        for (int j = 0; j < HIDDEN_SIZE; j++) {
            double grad = hiddenGrad[j];
            
            mBiasHidden[j] = BETA1 * mBiasHidden[j] + (1 - BETA1) * grad;
            vBiasHidden[j] = BETA2 * vBiasHidden[j] + (1 - BETA2) * grad * grad;
            
            double mHat = mBiasHidden[j] / (1 - Math.pow(BETA1, t));
            double vHat = vBiasHidden[j] / (1 - Math.pow(BETA2, t));
            
            biasHidden[j] -= learningRate * mHat / (Math.sqrt(vHat) + EPSILON);
        }
    }
    
    /**
     * Helper class to store forward pass results
     */
    private static class ForwardResult {
        double[] input;
        double[] hidden;
        double[] hiddenPreActivation;
        double[] output;
        double[] outputPreActivation;
    }
    
    /**
     * Training metrics to return from training
     */
    public static class TrainingMetrics {
        public double accuracy;
        public double loss;
        public int epochs;
        public double normalRecall;
        public double warningRecall;
        public double criticalRecall;
        
        public TrainingMetrics(double accuracy, double loss, int epochs, 
                             double normalRecall, double warningRecall, double criticalRecall) {
            this.accuracy = accuracy;
            this.loss = loss;
            this.epochs = epochs;
            this.normalRecall = normalRecall;
            this.warningRecall = warningRecall;
            this.criticalRecall = criticalRecall;
        }
    }
}
