package com.healthcare.fog.ml;

import com.healthcare.fog.entities.HealthcareTask;
import java.util.Random;

/**
 * Mock ML Model Service that simulates ECG anomaly detection
 * without requiring actual ONNX model files
 */
public class MockModelService {
    private Random random;
    private boolean isInitialized;

    public MockModelService() {
        this.random = new Random(42); // Fixed seed for reproducible results
        this.isInitialized = true;
        System.out.println("✓ Mock ML Model Service initialized successfully");
        System.out.println("✓ Hybrid ECG Model: Simulated");
        System.out.println("✓ CNN ECG Quantized Model: Simulated");
    }

    /**
     * Simulate processing task with Hybrid ECG model
     * Returns [normalizedScore, rawAnomalyScore]
     */
    public double[] processECGTaskWithAnomalyScore(HealthcareTask task) {
        if (!isInitialized) {
            return new double[]{0.0, 0.0};
        }

        try {
            // Simulate model processing time
            Thread.sleep(10);

            // Generate realistic anomaly scores based on task characteristics
            double baseScore = calculateBaseAnomalyScore(task);

            // Add some randomness to simulate model variation
            double variation = (random.nextDouble() - 0.5) * 0.3;
            double rawAnomalyScore = Math.max(0.1, Math.min(1.0, baseScore + variation));

            // Normalize score with different scaling for more realistic distribution
            double normalizedScore = applyNormalization(rawAnomalyScore, task);

            // System.out.printf("Mock Hybrid ECG: Task %d -> base=%.3f, raw=%.3f, normalized=%.3f%n",
            //         task.getTaskId(), baseScore, rawAnomalyScore, normalizedScore);

            return new double[]{normalizedScore, rawAnomalyScore};

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new double[]{0.0, 0.0};
        } catch (Exception e) {
            System.err.println("Error in mock ECG processing: " + e.getMessage());
            return new double[]{0.0, 0.0};
        }
    }

    /**
     * Simulate processing task with CNN ECG model
     * Returns [normalizedScore, rawAnomalyScore]
     */
    public double[] processCnnECGTaskWithAnomalyScore(HealthcareTask task) {
        if (!isInitialized) {
            return new double[]{0.0, 0.0};
        }

        try {
            // Simulate model processing time (CNN is usually faster)
            Thread.sleep(5);

            // CNN model might have different characteristics
            double baseScore = calculateBaseAnomalyScore(task);

            // CNN typically has different response patterns
            double cnnBias = 0.1; // CNN might be more sensitive
            double variation = (random.nextDouble() - 0.5) * 0.25;
            double rawAnomalyScore = Math.max(0.1, Math.min(1.0, baseScore + cnnBias + variation));

            // CNN-specific normalization
            double normalizedScore = applyCnnNormalization(rawAnomalyScore, task);

            // System.out.printf("Mock CNN ECG: Task %d -> base=%.3f, raw=%.3f, normalized=%.3f%n",
            //         task.getTaskId(), baseScore, rawAnomalyScore, normalizedScore);

            return new double[]{normalizedScore, rawAnomalyScore};

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new double[]{0.0, 0.0};
        } catch (Exception e) {
            System.err.println("Error in mock CNN ECG processing: " + e.getMessage());
            return new double[]{0.0, 0.0};
        }
    }

    /**
     * Calculate base anomaly score based on task characteristics
     * This simulates how real ML models would interpret task data
     */
    private double calculateBaseAnomalyScore(HealthcareTask task) {
        // Realistic scoring based on medical task characteristics
        double score = 0.0;

        // Urgency is a strong indicator - critical patients more likely to have anomalies
        score += (task.getUrgency() / 10.0) * 0.4;

        // Tight deadlines might indicate emergency situations
        double deadlineFactor = 1.0 - (Math.min(task.getDeadlineMs(), 1000) / 1000.0);
        score += deadlineFactor * 0.3;

        // Higher CPU requirements might indicate complex data (like detailed ECG)
        score += (Math.min(task.getCpuReqMI(), 2000) / 2000.0) * 0.2;

        // Data size might indicate comprehensive monitoring
        score += (Math.min(task.getDataSizeBytes(), 1000) / 1000.0) * 0.1;

        // Task type specific biases (medical domain knowledge)
        score += getTaskTypeBias(task.getTaskType());

        return Math.max(0.1, Math.min(0.9, score));
    }

    /**
     * Simulate different model behaviors for different task types
     */
    private double getTaskTypeBias(String taskType) {
        switch (taskType.toLowerCase()) {
            case "heartbeat":
                return 0.15; // Heartbeat anomalies are critical
            case "respirationrate":
                return 0.10; // Respiration issues are serious
            case "bloodpressure":
                return 0.05; // BP variations can be significant
            case "temperature":
                return -0.05; // Temperature is less critical alone
            default:
                return 0.0;
        }
    }

    /**
     * Apply realistic normalization for Hybrid model
     */
    private double applyNormalization(double rawScore, HealthcareTask task) {
        // Hybrid model might have different output characteristics
        double normalized = rawScore;

        // Adjust based on task urgency (real models might do this)
        if (task.getUrgency() >= 8) {
            normalized *= 1.1; // Boost scores for high urgency
        }

        // Ensure bounds
        return Math.max(0.1, Math.min(1.0, normalized));
    }

    /**
     * Apply CNN-specific normalization
     */
    private double applyCnnNormalization(double rawScore, HealthcareTask task) {
        // CNN models often have different output distributions
        double normalized = rawScore;

        // CNN might be better at detecting certain patterns
        if (task.getTaskType().equalsIgnoreCase("heartbeat")) {
            normalized *= 1.05; // CNN good with temporal patterns like heartbeat
        }

        // Ensure bounds
        return Math.max(0.1, Math.min(1.0, normalized));
    }

    /**
     * Legacy method for compatibility
     */
    public double processECGTask(HealthcareTask task) {
        double[] results = processECGTaskWithAnomalyScore(task);
        return results[0]; // Return only normalized score
    }

    /**
     * Legacy method for compatibility
     */
    public double processCnnECGTask(HealthcareTask task) {
        double[] results = processCnnECGTaskWithAnomalyScore(task);
        return results[0]; // Return only normalized score
    }

    /**
     * Adjust task priority based on model predictions (like original)
     */
    public void adjustTaskPriority(HealthcareTask task, double modelScore) {
        if (modelScore > 0.7) {
            // High anomaly score - increase urgency
            int newUrgency = Math.min(10, task.getUrgency() + 2);
            task.setUrgency(newUrgency);
            System.out.println("📈 Task " + task.getTaskId() + " urgency increased to " +
                    newUrgency + " based on ML score: " + String.format("%.3f", modelScore));
        } else if (modelScore > 0.5) {
            // Medium score - slight increase
            int newUrgency = Math.min(10, task.getUrgency() + 1);
            task.setUrgency(newUrgency);
            System.out.println("📈 Task " + task.getTaskId() + " urgency increased to " +
                    newUrgency + " based on ML score: " + String.format("%.3f", modelScore));
        }
    }

    /**
     * Simulate model performance metrics
     */
    public void printModelStats() {
        System.out.println("\n=== Mock ML Model Statistics ===");
        System.out.println("Hybrid ECG Model: Simulated (Real-time processing)");
        System.out.println("CNN ECG Model: Simulated (Quantized, Fast inference)");
        System.out.println("Average Inference Time: ~10ms");
        System.out.println("Anomaly Detection Accuracy: ~92% (Simulated)");
        System.out.println("Supported Task Types: All medical vital signs");
    }

    public void close() {
        this.isInitialized = false;
        System.out.println("✓ Mock ML Model Service shutdown");
    }

    public boolean isInitialized() {
        return isInitialized;
    }
}