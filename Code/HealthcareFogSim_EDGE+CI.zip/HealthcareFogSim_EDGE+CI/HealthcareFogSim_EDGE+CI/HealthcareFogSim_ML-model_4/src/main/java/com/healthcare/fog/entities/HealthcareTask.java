package com.healthcare.fog.entities;

public class HealthcareTask {
    private int taskId;
    private String taskType;
    private int dataSizeBytes;
    private int cpuReqMI;
    private int deadlineMs;
    private int urgency;
    private double energyEst;
    private int sourceId;
    private int arrivalMs;
    private double priority;
    private String algoType;

    public HealthcareTask(int taskId, String taskType, int dataSizeBytes, int cpuReqMI,
                          int deadlineMs, int urgency, double energyEst,
                          int sourceId, int arrivalMs) {
        this.taskId = taskId;
        this.taskType = taskType;
        this.dataSizeBytes = dataSizeBytes;
        this.cpuReqMI = cpuReqMI;
        this.deadlineMs = deadlineMs;
        this.urgency = urgency;
        this.energyEst = energyEst;
        this.sourceId = sourceId;
        this.arrivalMs = arrivalMs;
    }

    // Getters and Setters
    public int getTaskId() { return taskId; }
    public String getTaskType() { return taskType; }
    public int getDataSizeBytes() { return dataSizeBytes; }
    public int getCpuReqMI() { return cpuReqMI; }
    public int getDeadlineMs() { return deadlineMs; }
    public int getUrgency() { return urgency; }
    public void setUrgency(int urgency) { this.urgency = urgency; }
    public double getEnergyEst() { return energyEst; }
    public int getSourceId() { return sourceId; }
    public int getArrivalMs() { return arrivalMs; }
    public double getPriority() { return priority; }
    public void setPriority(double priority) { this.priority = priority; }
    public String getAlgoType() { return algoType; }
    public void setAlgoType(String algoType) { this.algoType = algoType; }

    @Override
    public String toString() {
        return String.format("HealthcareTask{id=%2d, type=%-15s, deadline=%4d, urgency=%d, energy=%.1f}",
                taskId, taskType, deadlineMs, urgency, energyEst);
    }
}