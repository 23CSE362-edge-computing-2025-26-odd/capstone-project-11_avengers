package com.healthcare.fog.dashboard;

import static spark.Spark.*;
import com.google.gson.Gson;
import java.util.*;
import java.time.LocalTime;

public class AlertDashboard {
    private static List<Map<String, String>> alerts = Collections.synchronizedList(new ArrayList<>());
    private static Gson gson = new Gson();

    public static void startServer() {
        port(5000);
        staticFiles.location("/public"); // serve HTML files from resources/public/

        // Endpoint to receive alerts from simulation
        post("/send_alert", (req, res) -> {
            Map<String, String> data = gson.fromJson(req.body(), Map.class);
            data.put("time", LocalTime.now().toString());
            alerts.add(0, data);
            System.out.println("⚠ Alert Received: " + data);
            return "{\"status\": \"ok\"}";
        });

        // Endpoint to get all alerts
        get("/alerts", (req, res) -> {
            res.type("application/json");
            return gson.toJson(alerts);
        });

        // Endpoint to clear alerts
        post("/clear_alerts", (req, res) -> {
            alerts.clear();
            return "{\"status\": \"cleared\"}";
        });
    }
}
