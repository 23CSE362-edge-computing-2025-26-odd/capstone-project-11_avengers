package com.healthcare.fog.utils;

import com.healthcare.fog.entities.HealthcareTask;
import com.healthcare.fog.entities.FogDeviceInfo;
import java.util.List;

public class MBAR {
    public static double calculatePriority(HealthcareTask task, List<FogDeviceInfo> fogDevices) {
        double bestReliability = fogDevices.stream()
                .mapToDouble(FogDeviceInfo::getReliability)
                .max().orElse(0.5);

        double normUrgency = task.getUrgency() / 10.0;
        double normDeadline = 1.0 - (Math.min(task.getDeadlineMs(), 1000) / 1000.0);

        double w1 = 0.3; // deadline
        double w2 = 0.4; // urgency
        double w3 = 0.3; // reliability

        double score = (w1 * normDeadline) + (w2 * normUrgency) + (w3 * bestReliability);
        return Math.max(0.0, Math.min(1.0, score));
    }
}