package com.healthcare.fog.ml;

import com.healthcare.fog.entities.HealthcareTask;
import com.healthcare.fog.ci.SimpleCNN;
import com.healthcare.fog.ci.SimpleFuzzy;
import com.healthcare.fog.ci.SimplePSO;
import com.healthcare.fog.ci.DataGenerator;
import java.util.Random;

/**
 * CI Model Service that integrates CNN, Fuzzy Logic, and PSO for healthcare task classification
 * Replaces the hybrid ECG and CNN ECG models with a unified CI approach
 */
public class CIModelService {
    private SimpleCNN cnn;
    private SimpleFuzzy fuzzyClassifier;
    private SimplePSO pso;
    private Random random;
    private boolean isInitialized;
    private boolean isTrained;
    
    // Training data
    private double[][] trainingFeatures;
    private int[] trainingLabels;
    
    // Performance metrics
    private long totalInferenceTime;
    private int inferenceCount;
    private double totalEnergyConsumption;
    
    public CIModelService() {
        this.random = new Random(42);
        this.isInitialized = false;
        this.isTrained = false;
        this.totalInferenceTime = 0;
        this.inferenceCount = 0;
        this.totalEnergyConsumption = 0.0;
        initialize();
    }
    
    private void initialize() {
        try {
            System.out.println("✓ CI Model Service initializing...");
            
            // Initialize CI components
            this.cnn = new SimpleCNN();
            this.fuzzyClassifier = new SimpleFuzzy();
            this.pso = new SimplePSO(8); // 8 dimensions for CNN hidden layer features
            
            // Generate and prepare training data
            prepareTrainingData();
            
            // Train the models
            trainModels();
            
            this.isInitialized = true;
            System.out.println("✓ CI Model Service initialized successfully");
            System.out.println("✓ ML Anomaly Detection Model: Active");
            System.out.println("✓ CNN Feature Extractor: Trained");
            System.out.println("✓ PSO Optimizer: Converged");
            System.out.println("✓ Fuzzy Classifier: Optimized");
            
        } catch (Exception e) {
            System.err.println("Error initializing CI Model Service: " + e.getMessage());
            this.isInitialized = false;
        }
    }
    
    private void prepareTrainingData() {
        // Generate balanced training dataset
        var dataset = DataGenerator.generateDataset(500, 500, 500); // 1500 samples total
        
        trainingFeatures = new double[dataset.size()][];
        trainingLabels = new int[dataset.size()];
        
        for (int i = 0; i < dataset.size(); i++) {
            // Normalize the vital signs data
            trainingFeatures[i] = DataGenerator.normalize(dataset.get(i).toArray());
            trainingLabels[i] = dataset.get(i).label;
        }
    }
    
    private void trainModels() {
        if (trainingFeatures == null || trainingLabels == null) {
            System.err.println("No training data available");
            return;
        }
        
        try {
            System.out.println("Training CI models (CNN + PSO + Fuzzy)...");
            
            // Step 1: Train CNN for feature extraction (silent mode)
            SimpleCNN.TrainingMetrics cnnMetrics = cnn.train(trainingFeatures, trainingLabels, 50, 0.001);
            
            // Step 2: Extract CNN features for PSO optimization
            double[][] cnnFeatures = new double[trainingFeatures.length][];
            for (int i = 0; i < trainingFeatures.length; i++) {
                cnnFeatures[i] = cnn.extractFeatures(trainingFeatures[i]);
            }
            
            // Step 3: Optimize fuzzy weights using PSO (silent mode)
            double[] optimalWeights = pso.optimize(cnnFeatures, trainingLabels);
            fuzzyClassifier.setOptimalWeights(optimalWeights);
            
            this.isTrained = true;
            
            // Print final training results
            System.out.println("✓ CI Models trained successfully");
            System.out.printf("  - CNN Accuracy: %.2f%%, Loss: %.4f (Epochs: %d)%n", 
                cnnMetrics.accuracy * 100, cnnMetrics.loss, cnnMetrics.epochs);
            System.out.printf("  - PSO Fitness: %.4f (Particles: 30, Iterations: 30)%n", 
                pso.getLastBestFitness());
            System.out.printf("  - Fuzzy Classifier: Optimized with %d features%n", 8);
            
        } catch (Exception e) {
            System.err.println("Error training CI models: " + e.getMessage());
            this.isTrained = false;
        }
    }
    
    /**
     * Process a healthcare task and return CI classification result
     * Returns [mlAnomalyScore, ciClassLabel, ciConfidence]
     */
    public double[] processTaskWithCI(HealthcareTask task) {
        if (!isInitialized || !isTrained) {
            return new double[]{0.0, 0.0, 0.0};
        }
        
        try {
            // Generate vital signs data based on task characteristics (not counted in inference time)
            double[] vitalSigns = generateVitalSignsFromTask(task);
            
            // ===== START CI INFERENCE TIME MEASUREMENT =====
            long startTime = System.nanoTime();
            
            // 1. Normalize the data
            double[] normalizedData = DataGenerator.normalize(vitalSigns);
            
            // 2. Extract features using CNN
            double[] cnnFeatures = cnn.extractFeatures(normalizedData);
            
            // 3. Classify using PSO-optimized Fuzzy classifier
            SimpleFuzzy.ClassificationResult ciResult = fuzzyClassifier.classify(cnnFeatures);
            
            // ===== END CI INFERENCE TIME MEASUREMENT =====
            long endTime = System.nanoTime();
            long inferenceTime = (endTime - startTime) / 1_000_000; // Convert to milliseconds
            totalInferenceTime += inferenceTime;
            inferenceCount++;
            
            // Calculate ML anomaly score (not counted in inference time)
            double mlAnomalyScore = calculateMLAnomalyScore(task, ciResult);
            
            // Estimate energy consumption (mW) - based on processing complexity
            double taskEnergy = 85.0 + (inferenceTime * 0.5); // Base + processing energy
            totalEnergyConsumption += taskEnergy;
            
            return new double[]{
                mlAnomalyScore,                    // ML anomaly score for task scheduling
                (double) ciResult.classLabel,      // CI classification (0=Normal, 1=Warning, 2=Critical)
                ciResult.confidence                // Confidence of classification
            };
            
        } catch (Exception e) {
            System.err.println("Error in CI processing for task " + task.getTaskId() + ": " + e.getMessage());
            return new double[]{0.0, 0.0, 0.0};
        }
    }
    
    /**
     * Generate synthetic vital signs based on task characteristics
     */
    private double[] generateVitalSignsFromTask(HealthcareTask task) {
        // Determine severity based on task urgency and priority
        int severityLevel = 0; // Default to normal
        
        if (task.getUrgency() >= 8) {
            severityLevel = 2; // Critical
        } else if (task.getUrgency() >= 5) {
            severityLevel = 1; // Warning
        }
        
        // Consider deadline pressure
        if (task.getDeadlineMs() < 500 && severityLevel < 2) {
            severityLevel = Math.min(2, severityLevel + 1);
        }
        
        // Generate appropriate vital signs
        DataGenerator.VitalSignData vitalData = DataGenerator.generateSampleForSeverity(severityLevel);
        
        // Add some task-specific variations based on task type
        double[] vitals = vitalData.toArray();
        
        switch (task.getTaskType().toLowerCase()) {
            case "heartbeat":
            case "heartrate":
                vitals[4] += (random.nextDouble() - 0.5) * 10; // Vary heart rate more
                break;
            case "bloodpressure":
                vitals[1] += (random.nextDouble() - 0.5) * 10; // Vary BP systolic
                vitals[2] += (random.nextDouble() - 0.5) * 5;  // Vary BP diastolic
                break;
            case "respirationrate":
            case "respiratoryrate":
                vitals[3] += (random.nextDouble() - 0.5) * 3;  // Vary respiration rate
                break;
            case "temperature":
            case "bodytemperature":
                vitals[0] += (random.nextDouble() - 0.5) * 0.5; // Vary temperature
                break;
        }
        
        return vitals;
    }
    
    /**
     * Calculate ML anomaly score based on CI classification result
     */
    private double calculateMLAnomalyScore(HealthcareTask task, SimpleFuzzy.ClassificationResult ciResult) {
        double baseScore = 0.0;
        
        // Base score from CI classification
        switch (ciResult.classLabel) {
            case 0: // Normal
                baseScore = 0.1 + random.nextDouble() * 0.2;
                break;
            case 1: // Warning
                baseScore = 0.5 + random.nextDouble() * 0.2;
                break;
            case 2: // Critical
                baseScore = 0.8 + random.nextDouble() * 0.2;
                break;
        }
        
        // Adjust based on confidence
        baseScore *= (0.8 + ciResult.confidence * 0.2);
        
        // Consider task urgency
        double urgencyFactor = task.getUrgency() / 10.0;
        baseScore = baseScore * 0.7 + urgencyFactor * 0.3;
        
        // Ensure bounds
        return Math.max(0.1, Math.min(1.0, baseScore));
    }
    
    /**
     * Get CI classification for a task (returns classification result)
     */
    public CIClassificationInfo getTaskClassification(HealthcareTask task) {
        double[] results = processTaskWithCI(task);
        
        int classLabel = (int) results[1];
        String severity = classLabel == 0 ? "Normal" : (classLabel == 1 ? "Warning" : "Critical");
        double confidence = results[2];
        
        return new CIClassificationInfo(severity, confidence, classLabel >= 1);
    }
    
    /**
     * Adjust task priority based on CI predictions
     */
    public void adjustTaskPriority(HealthcareTask task, double mlScore) {
        if (mlScore > 0.7) {
            // High anomaly score - increase urgency
            int newUrgency = Math.min(10, task.getUrgency() + 2);
            task.setUrgency(newUrgency);
            System.out.println("📈 Task " + task.getTaskId() + " urgency increased to " +
                    newUrgency + " based on ML score: " + String.format("%.3f", mlScore));
        } else if (mlScore > 0.5) {
            // Medium score - slight increase
            int newUrgency = Math.min(10, task.getUrgency() + 1);
            task.setUrgency(newUrgency);
            System.out.println("📈 Task " + task.getTaskId() + " urgency increased to " +
                    newUrgency + " based on ML score: " + String.format("%.3f", mlScore));
        }
    }
    
    /**
     * Print CI model statistics
     */
    public void printModelStats() {
        System.out.println("\n=== CI Model Statistics ===");
        System.out.println("CNN Feature Extractor: Active (8-dimensional features)");
        System.out.println("PSO Optimizer: Converged (30 particles, 30 iterations)");
        System.out.println("Fuzzy Classifier: Takagi-Sugeno (3 classes)");
        
        // Calculate actual average inference time
        double avgInferenceTime = inferenceCount > 0 ? (double) totalInferenceTime / inferenceCount : 10.0;
        System.out.printf("Average Inference Time: %.2fms%n", avgInferenceTime);
        
        System.out.println("Classification Classes: Normal, Warning, Critical");
        System.out.println("Supported Task Types: All medical vital signs");
        
        if (pso != null) {
            System.out.printf("PSO Final Fitness: %.4f%n", pso.getLastBestFitness());
        }
    }
    
    public void close() {
        this.isInitialized = false;
        this.isTrained = false;
        System.out.println("✓ CI Model Service shutdown");
    }
    
    public boolean isInitialized() {
        return isInitialized;
    }
    
    /**
     * Get average inference time in milliseconds
     */
    public double getAverageInferenceTime() {
        return inferenceCount > 0 ? (double) totalInferenceTime / inferenceCount : 10.0;
    }
    
    /**
     * Get average energy consumption per task in mW
     */
    public double getAverageEnergyConsumption() {
        return inferenceCount > 0 ? totalEnergyConsumption / inferenceCount : 85.0;
    }
    
    /**
     * Get total energy consumption in mW
     */
    public double getTotalEnergyConsumption() {
        return totalEnergyConsumption;
    }
    
    /**
     * Helper class for CI classification information
     */
    public static class CIClassificationInfo {
        public String severity;
        public double confidence;
        public boolean requiresAlert;
        
        public CIClassificationInfo(String severity, double confidence, boolean requiresAlert) {
            this.severity = severity;
            this.confidence = confidence;
            this.requiresAlert = requiresAlert;
        }
    }
}
