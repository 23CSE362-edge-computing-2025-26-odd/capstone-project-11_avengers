package com.healthcare.fog.ci;

/**
 * Simplified Takagi-Sugeno Fuzzy Classifier
 */
public class SimpleFuzzy {
    private double[] optimalWeights;
    
    public class ClassificationResult {
        public int classLabel;
        public String severity;
        public double confidence;
        public double[] membershipDegrees;
        public double aggregatedScore;
        public boolean requiresAlert;
        
        public ClassificationResult(int classLabel, String severity, double confidence,
                                   double[] membershipDegrees, double aggregatedScore) {
            this.classLabel = classLabel;
            this.severity = severity;
            this.confidence = confidence;
            this.membershipDegrees = membershipDegrees;
            this.aggregatedScore = aggregatedScore;
            this.requiresAlert = (classLabel >= 1); // Alert for Warning and Critical
        }
    }
    
    public SimpleFuzzy() {
    }
    
    /**
     * Set optimal weights from PSO
     */
    public void setOptimalWeights(double[] weights) {
        this.optimalWeights = weights.clone();
    }
    
    /**
     * Triangular membership function
     */
    private double triangularMF(double x, double a, double b, double c) {
        if (x <= a || x >= c) {
            return 0.0;
        } else if (x == b) {
            return 1.0;
        } else if (x < b) {
            return (x - a) / (b - a);
        } else {
            return (c - x) / (c - b);
        }
    }
    
    /**
     * Classify a single sample
     */
    public ClassificationResult classify(double[] features) {
        // Calculate weighted score
        double score = 0;
        for (int i = 0; i < Math.min(features.length, optimalWeights.length); i++) {
            score += features[i] * optimalWeights[i];
        }
        
        // Calculate membership degrees with wider Warning range for better detection
        double muNormal = triangularMF(score, 0.0, 0.06, 0.11);
        double muWarning = triangularMF(score, 0.09, 0.13, 0.17);
        double muCritical = triangularMF(score, 0.14, 0.20, 1.0);
        
        // Normalize memberships
        double sum = muNormal + muWarning + muCritical;
        if (sum > 0) {
            muNormal /= sum;
            muWarning /= sum;
            muCritical /= sum;
        } else {
            // If all memberships are 0, assign to Normal with minimum confidence
            muNormal = 1.0;
            muWarning = 0.0;
            muCritical = 0.0;
        }
        
        // Takagi-Sugeno defuzzification
        double output = muNormal * 0.0 + muWarning * 1.0 + muCritical * 2.0;
        
        // Determine class
        int classLabel;
        String severity;
        double confidence;
        
        if (output < 0.5) {
            classLabel = 0;
            severity = "Normal";
            confidence = Math.max(muNormal, 0.5); // Ensure minimum confidence of 0.5
        } else if (output < 1.5) {
            classLabel = 1;
            severity = "Warning";
            confidence = Math.max(muWarning, 0.5); // Ensure minimum confidence of 0.5
        } else {
            classLabel = 2;
            severity = "Critical";
            confidence = Math.max(muCritical, 0.5); // Ensure minimum confidence of 0.5
        }
        
        double[] memberships = {muNormal, muWarning, muCritical};
        return new ClassificationResult(classLabel, severity, confidence, memberships, score);
    }
    
    /**
     * Classify batch of samples
     */
    public ClassificationResult[] classifyBatch(double[][] features) {
        ClassificationResult[] results = new ClassificationResult[features.length];
        for (int i = 0; i < features.length; i++) {
            results[i] = classify(features[i]);
        }
        return results;
    }
    
    /**
     * Calculate accuracy
     */
    public double calculateAccuracy(ClassificationResult[] results, int[] trueLabels) {
        int correct = 0;
        for (int i = 0; i < results.length; i++) {
            if (results[i].classLabel == trueLabels[i]) {
                correct++;
            }
        }
        return (double) correct / results.length;
    }
}
