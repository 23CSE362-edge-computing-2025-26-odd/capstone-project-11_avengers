# Healthcare Fog Simulation - CI Alert Dashboard

## Overview
This dashboard provides real-time monitoring of critical patient alerts detected by the CI (Computational Intelligence) models (CNN+PSO+Fuzzy) during the Healthcare Fog Simulation.

## Features
- **Real-time Alert Monitoring**: Displays alerts as they are detected by the simulation
- **CI Classification**: Shows Normal, Warning, and Critical patient states
- **ML Anomaly Scores**: Displays machine learning anomaly detection scores
- **Auto-refresh**: Updates every 2 seconds automatically
- **Statistics Dashboard**: Shows total alerts, critical alerts, warnings, and normal high-priority tasks
- **Beautiful UI**: Modern, responsive design with color-coded alerts

## Prerequisites

### Required Dependencies
You need to add the following dependencies to your project:

#### 1. Spark Java (Web Framework)
```xml
<!-- Add to pom.xml if using Maven -->
<dependency>
    <groupId>com.sparkjava</groupId>
    <artifactId>spark-core</artifactId>
    <version>2.9.4</version>
</dependency>
```

#### 2. Gson (JSON Processing)
```xml
<dependency>
    <groupId>com.google.code.gson</groupId>
    <artifactId>gson</artifactId>
    <version>2.10.1</version>
</dependency>
```

#### 3. SLF4J (Logging - required by Spark)
```xml
<dependency>
    <groupId>org.slf4j</groupId>
    <artifactId>slf4j-simple</artifactId>
    <version>2.0.9</version>
</dependency>
```

### For Non-Maven Projects
Download the JAR files manually:
1. **spark-core-2.9.4.jar** from https://mvnrepository.com/artifact/com.sparkjava/spark-core/2.9.4
2. **gson-2.10.1.jar** from https://mvnrepository.com/artifact/com.google.code.gson/gson/2.10.1
3. **slf4j-simple-2.0.9.jar** from https://mvnrepository.com/artifact/org.slf4j/slf4j-simple/2.0.9
4. **slf4j-api-2.0.9.jar** from https://mvnrepository.com/artifact/org.slf4j/slf4j-api/2.0.9
5. **jetty-server** and other Jetty dependencies (required by Spark)

Place all JAR files in a `lib` folder and add them to your classpath.

## Project Structure
```
HealthcareFogSim_ML-model_4/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/healthcare/fog/
│   │   │       ├── controller/
│   │   │       │   └── HealthcareFogSimulator.java  (Main simulation)
│   │   │       └── dashboard/
│   │   │           └── AlertDashboard.java          (Dashboard server)
│   │   └── resources/
│   │       └── public/
│   │           └── index.html                        (Dashboard UI)
└── test1.csv                                          (Task data)
```

## How to Run

### Step 1: Compile the Project
```bash
javac -d out -cp "lib/*:." src/main/java/com/healthcare/fog/**/*.java
```

### Step 2: Run the Simulation
```bash
java -cp "out:lib/*" com.healthcare.fog.controller.HealthcareFogSimulator
```

### Step 3: Access the Dashboard
The dashboard will automatically open in your default browser at:
```
http://localhost:5000
```

If it doesn't open automatically, manually navigate to the URL above.

## Dashboard Features

### 1. Statistics Cards
- **Total Alerts**: Count of all alerts generated
- **Critical Alerts**: Tasks classified as Critical by CI model
- **Warning Alerts**: Tasks classified as Warning by CI model
- **Normal (High Priority)**: Normal tasks with high urgency

### 2. Alert Feed
Each alert displays:
- **Patient Task ID**: Unique identifier for the task
- **Task Type**: Type of medical measurement (ECG, Heartbeat, etc.)
- **ML Anomaly Score**: Machine learning anomaly detection score (0-1)
- **CI Classification**: CI model classification (Normal/Warning/Critical)
- **CI Confidence**: Confidence level of the classification (0-1)
- **Alert Reason**: Detailed explanation of why the alert was triggered
- **Timestamp**: When the alert was detected

### 3. Controls
- **🔄 Refresh Now**: Manually refresh the alert feed
- **🗑️ Clear All Alerts**: Clear all alerts from the dashboard

## Alert Classification

### Critical (Red)
- CI Classification: Critical
- ML Anomaly Score ≥ 0.8
- High Urgency (≥ 8)
- Requires immediate attention

### Warning (Orange)
- CI Classification: Warning
- Moderate anomaly scores
- Potential patient deterioration

### Normal (Green)
- CI Classification: Normal
- High priority but stable condition
- Routine monitoring

## Troubleshooting

### Dashboard doesn't start
- **Issue**: Missing dependencies
- **Solution**: Ensure all required JAR files are in the classpath

### Browser doesn't open automatically
- **Issue**: OS-specific browser opening failed
- **Solution**: Manually open http://localhost:5000

### Port 5000 already in use
- **Issue**: Another application is using port 5000
- **Solution**: Change the port in `AlertDashboard.java`:
  ```java
  port(5001); // Change to any available port
  ```

### Alerts not appearing
- **Issue**: Dashboard server not receiving data
- **Solution**: Check that the simulation is running and generating alerts

## Technical Details

### Architecture
1. **Simulation (Main Thread)**: Processes healthcare tasks with CI models
2. **Dashboard Server (Separate Thread)**: Runs Spark web server on port 5000
3. **HTTP Communication**: Simulation sends alerts via POST requests
4. **Auto-refresh**: Frontend polls `/alerts` endpoint every 2 seconds

### API Endpoints
- `POST /send_alert`: Receive new alerts from simulation
- `GET /alerts`: Retrieve all alerts
- `POST /clear_alerts`: Clear all alerts
- `GET /`: Serve dashboard HTML

### Data Flow
```
Simulation → CI Models → Alert Detection → HTTP POST → Dashboard Server → Browser
```

## Customization

### Change Refresh Rate
Edit `index.html`:
```javascript
setInterval(fetchAlerts, 2000); // Change 2000 to desired milliseconds
```

### Modify Alert Thresholds
Edit `HealthcareFogSimulator.java`:
```java
boolean alert = task.getUrgency() >= 8 || mlAnomalyScore >= 0.8 || ciClassLabel >= 1;
```

### Change Dashboard Port
Edit `AlertDashboard.java`:
```java
port(5000); // Change to desired port
```

## Credits
- **CI Models**: CNN + PSO + Fuzzy Logic
- **Web Framework**: Spark Java
- **JSON Processing**: Gson
- **UI Design**: Custom CSS with gradient backgrounds

## License
This dashboard is part of the Healthcare Fog Simulation project.
